<?php include __DIR__ . "/../layout/header.php"; ?>
<p style="font-size: 22px;" class="m-3">This is a demo page so don't judge that the dashboard is so empty 🤪</p>
<ul>
    <li>
        <a class="text-light display-6 text-decoration-none" href="admin-index">Edit Posts</a>
    </li>
    <li>
        <a class="text-light display-6 text-decoration-none" href="logout">Logout</a>
    </li>
</ul>
   

<?php include __DIR__ . "/../layout/footer.php"; ?>